# aircrack-ng-handshakes
Get handshake files every week for practicing bruteforce attack
